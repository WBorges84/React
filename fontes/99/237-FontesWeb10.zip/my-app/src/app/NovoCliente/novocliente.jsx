import React from 'react';
import './novocliente.css';

function NovoCliente(){
    return <div>
        <h1>Novo cliente...</h1>
    </div>;  
  }

export default NovoCliente;