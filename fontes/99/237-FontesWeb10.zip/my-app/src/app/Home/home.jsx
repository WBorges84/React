import React from 'react';
import Navbar from '../Components/Navbar/navbar';
import './home.css';

function Home(){
    return <div>
      <Navbar/>
    </div>
  }

export default Home;